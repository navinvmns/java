USE [PlanDetails]

IF EXISTS (SELECT 1 FROM sys.triggers WHERE Name = 'TRG_QNA')
	DROP TRIGGER FAQ.TRG_QNA
/*******************************************************************************
NAME:       TRG_QNA
PURPOSE:    When QNA is updated or delete, back up the current record to QNA_HIST table.

BUILD-LABEL:  #BI#
BUILD-DATE:  #BD#

REVISIONS:
Ver        Date        Author           Description
---------  ----------  ---------------  ---------------------------
1.0        2/07/2018   NAVEEN KUMAR T         Created this TRIGGER.
******************************************************************************/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER FAQ.TRG_QNA ON FAQ.QNA
	AFTER UPDATE, DELETE
AS

	IF EXISTS (SELECT * FROM Inserted)
	  -- UPDATE Statement was executed
	  INSERT INTO QNA_HIST(
		CLIENT, 
		PLAN_ID, 
		DIVISION_CODE,
		DOCUMENT_ID,
		STATUS,
		QUESTION_SORTORDER,
		TRIGGER_TIMESTAMP,
		TRIGGER_ACTION,
		QUESTION,
		ANSWER,
		TEMPLATE_SECTIONID,
		TEMPLATESECTION_SORTORDER,
		ISACTIVE,
		CREATED_ON,
		CREATED_BY,
		MODLAST_ON,
		MODLAST_BY
	  )
	  SELECT
		d.CLIENT, 
		d.PLAN_ID, 
		d.DIVISION_CODE,
		d.DOCUMENT_ID,
		d.STATUS,
		d.QUESTION_SORTORDER,
		SYSDATETIME(),
		'UPDATE',
		d.QUESTION,
		d.ANSWER,
		d.TEMPLATE_SECTIONID,
		d.TEMPLATESECTION_SORTORDER,
		d.ISACTIVE,
		d.CREATED_ON,
		d.CREATED_BY,
		d.MODLAST_ON,
		d.MODLAST_BY
	  FROM Deleted d
	  INNER JOIN Inserted i 
		ON i.CLIENT = d.CLIENT 
		AND i.PLAN_ID = d.PLAN_ID 
		AND i.DIVISION_CODE = d.DIVISION_CODE 
		AND i.DOCUMENT_ID = d.DOCUMENT_ID
		AND i.STATUS = d.STATUS
	ELSE
		-- DELETE Statement was executed
		 INSERT INTO QNA_HIST(
		CLIENT, 
		PLAN_ID, 
		DIVISION_CODE,
		DOCUMENT_ID,
		STATUS,
		QUESTION_SORTORDER,
		TRIGGER_TIMESTAMP,
		TRIGGER_ACTION,
		QUESTION,
		ANSWER,
		TEMPLATE_SECTIONID,
		TEMPLATESECTION_SORTORDER,
		ISACTIVE,
		CREATED_ON,
		CREATED_BY,
		MODLAST_ON,
		MODLAST_BY
	  )
	  SELECT
		d.CLIENT, 
		d.PLAN_ID, 
		d.DIVISION_CODE,
		d.DOCUMENT_ID,
		d.STATUS,
		d.QUESTION_SORTORDER,
		SYSDATETIME(),
		'DELETE',
		d.QUESTION,
		d.ANSWER,
		d.TEMPLATE_SECTIONID,
		d.TEMPLATESECTION_SORTORDER,
		d.ISACTIVE,
		d.CREATED_ON,
		d.CREATED_BY,
		d.MODLAST_ON,
		d.MODLAST_BY
	  FROM Deleted d

GO


