USE [PlanDetails]
GO

GO  
IF OBJECT_ID('FAQ.USP_GET_CONFIG_DETAILS', 'P') IS NOT NULL  
    DROP PROCEDURE FAQ.USP_GET_CONFIG_DETAILS;  
GO  
/*******************************************************************************
NAME:       USP_GET_CONFIG_DETAILS
PURPOSE:    The main purpose of this procedure IS TO PROVIDE ALL THE
DATA ELEMENTS FOR A PARTICULAR application in terms of configuration data.

BUILD-LABEL:  #BI#
BUILD-DATE:  #BD#

Procedure Updates Database:
	NO
Procedure Calls Other Procs:
	NO
	
 Input Arguments:
        @I_APP_ID               VARCHAR(5)
        @O_SQLCODE				VARCHAR(3) OUTPUT
        @O_SQLMSG				VARCHAR(255) OUTPUT
       
 Output Arguments:
		@return_code                   CHAR(03)  
		@return_msg                    CHAR(255)       

Procedure Return Codes (code generated into @O_SQLCODE):
**     0 SUCCESSFUL
**     1 SUCCESSFUL   - No item
**    30 UNSUCCESSFUL - SQL Related      Error on SELECT 
**                               
**    2x UNSUCCESSFUL - Data Constraints N/A                                
**    4x UNSUCCESSFUL - External Proc    N/A                               
**    9x UNSUCCESSFUL - Other            N/A  

Procedure Returns Result Set:
	YES

Procedure Returns Result Set:
CATEGORY,
KEY_CD ,
KEY_VALUE	

REVISIONS:
Ver        Date        Author           Description
---------  ----------  ---------------  ---------------------------
1.0        2/06/2018   NAVEEN KUMAR T        Created this procedure.
******************************************************************************/
CREATE PROCEDURE FAQ.USP_GET_CONFIG_DETAILS (                              
                              @I_APP_ID VARCHAR(5),
                              @O_SQLCODE   VARCHAR(3) OUTPUT,
                              @O_SQLMSG    VARCHAR(255) OUTPUT) 
AS
-- SET NOCOUNT ON added to prevent extra result sets from 
-- interfering with SELECT statements. 
SET nocount ON; 
SET ANSI_WARNINGS OFF
SET QUOTED_IDENTIFIER OFF
/********************************************************************/
/*              D e c l a r a t i o n   of  V a r i a b l e s       */
/********************************************************************/
 
DECLARE       @error_var            INT
         ,    @rowcount_var         INT
           
/********************************************************************/
/*              I n i t i a l i z a t i o n                         */
/********************************************************************/


/********************************************************************/
/*              M a i n                                             */
/********************************************************************/
BEGIN
	PRINT '[USP_GET_CONFIG_DETAILS] START';
	IF (@I_APP_ID IS NULL OR @I_APP_ID = '')
	BEGIN
		PRINT '[USP_GET_CONFIG_DETAILS] APP_ID DEFAULT VALUE SET TO 100';
		SET @I_APP_ID = '100'
	END
     -- SET FLAG VALUES AND SQL CODE/MESSAGES
    SET @O_SQLCODE = 0;
    SET @O_SQLMSG = 'SUCCESS';
    
    -- SET XACT_ABORT to ON for ROLLED BACK whene the exception occure
	SET XACT_ABORT ON
	
	BEGIN TRY
		SELECT
			B.CAT_NAME CATEGORY,
			A.KEY_CD ,
			A.KEY_VALUE
		FROM
			CONFIG_DATA A, CONFIG_CATEGORY B
		WHERE A.APP_ID = @I_APP_ID
			AND A.ISACTIVE='Y'
			AND B.CAT_ID=A.CAT_ID
			AND B.ISACTIVE='Y'
			
		ORDER BY B.CAT_NAME,A.KEY_CD;
	/*************************************************/
    /*      Capture errors                           */
    /*************************************************/   
		SELECT  @error_var  = @@ERROR, @rowcount_var = @@ROWCOUNT     
	END TRY
    BEGIN CATCH
		PRINT '[USP_GET_CONFIG_DETAILS] CATCH BLOCK EXECUTION';
	    SET @O_SQLCODE = '30';
		SET @O_SQLMSG = '[USP_GET_CONFIG_DETAILS] UNSUCCESSFUL - SQL Error on SELECT: ' + SUBSTRING(CAST(@error_var AS CHAR(06)),1,200);
		RETURN
	END CATCH
   
   PRINT '[USP_GET_CONFIG_DETAILS] END';
	IF @error_var <> 0
	BEGIN
	   SELECT @O_SQLCODE = '30'
	   SELECT @O_SQLMSG  = '[USP_GET_CONFIG_DETAILS] UNSUCCESSFUL - SQL Error on SELECT: ' + ERROR_NUMBER()+' - '+ SUBSTRING(CAST(@error_var AS CHAR(06)),1,200)
	   RETURN
	END
	IF @rowcount_var <= 0
	BEGIN
		SELECT @O_SQLCODE = '1'
	   SELECT @O_SQLMSG  = '[USP_GET_CONFIG_DETAILS] SUCCESSFUL - No records found '
	   RETURN
	END
END 
    
   
GO 

--EXECUTE FAQ.USP_GET_CONFIG_DETAILS '101', @O_SQLCODE='1',@O_SQLMSG=''

