USE [PlanDetails]
GO

GO  
IF OBJECT_ID('FAQ.USP_GET_SITE_ELEMENTS', 'P') IS NOT NULL  
    DROP PROCEDURE FAQ.USP_GET_SITE_ELEMENTS;  
GO  
/*******************************************************************************
NAME:       USP_GET_SITE_ELEMENTS
PURPOSE:    The main purpose of this procedure IS TO PROVIDE ALL THE
DATA ELEMENTS FOR A PARTICULAR application in terms of configuration data.

BUILD-LABEL:  #BI#
BUILD-DATE:  #BD#

Procedure Updates Database:
	NO
Procedure Calls Other Procs:
	NO
	
 Input Arguments:
        @app_id     VARCHAR(5)
        @site_id    VARCHAR(5)
        @lang_id    VARCHAR(5)
        @O_SQLCODE				VARCHAR(3) OUTPUT
        @O_SQLMSG				VARCHAR(255) OUTPUT
       
 Output Arguments:
		@return_code                   CHAR(03)  
		@return_msg                    CHAR(255)       

Procedure Return Codes (code generated into @O_SQLCODE):
**     0 SUCCESSFUL
**     1 SUCCESSFUL   - No item
**    30 UNSUCCESSFUL - SQL Related      Error on SELECT 
**                               
**    2x UNSUCCESSFUL - Data Constraints N/A                                
**    4x UNSUCCESSFUL - External Proc    N/A                               
**    9x UNSUCCESSFUL - Other            N/A  

Procedure Returns Result Set:
	YES

Procedure Returns Result Set:
	elementName,
	elementValue,
	defaultElementValue,
	elementKey	

REVISIONS:
Ver        Date        Author           Description
---------  ----------  ---------------  ---------------------------
1.0        2/06/2018   NAVEEN KUMAR T        Created this procedure.
******************************************************************************/
CREATE PROCEDURE FAQ.USP_GET_SITE_ELEMENTS (                              
                              @app_id VARCHAR(5),
                              @site_id VARCHAR(5),
                              @lang_id VARCHAR(5),
                              @O_SQLCODE   VARCHAR(3) OUTPUT,
                              @O_SQLMSG    VARCHAR(255) OUTPUT) 
AS
-- SET NOCOUNT ON added to prevent extra result sets from 
-- interfering with SELECT statements. 
SET nocount ON; 
SET ANSI_WARNINGS OFF
SET QUOTED_IDENTIFIER OFF
/********************************************************************/
/*              D e c l a r a t i o n   of  V a r i a b l e s       */
/********************************************************************/
 
DECLARE       @error_var            INT
         ,    @rowcount_var         INT
           
/********************************************************************/
/*              I n i t i a l i z a t i o n                         */
/********************************************************************/


/********************************************************************/
/*              M a i n                                             */
/********************************************************************/
BEGIN
	PRINT '[USP_GET_SITE_ELEMENTS] START';
	IF (@app_id IS NULL OR @app_id = '')
	BEGIN
		PRINT '[USP_GET_SITE_ELEMENTS] APP_ID DEFAULT VALUE SET TO 100';
		SET @app_id = '100'
	END
	--Input Argument "site_id" validation
	IF (@site_id IS NULL OR @site_id = '')
	BEGIN
		PRINT '[USP_GET_PLAN_DETAILS] site_id parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] Input Arguments - site_id can not be null or Empty. ';
		RETURN
	END
	--Input Argument "lang_id" validation
	IF (@lang_id IS NULL OR @lang_id = '')
	BEGIN
		PRINT '[USP_GET_PLAN_DETAILS] lang_id parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] Input Arguments - lang_id can not be null or Empty. ';
		RETURN
	END
     -- SET FLAG VALUES AND SQL CODE/MESSAGES
    SET @O_SQLCODE = 0;
    SET @O_SQLMSG = 'SUCCESS';
    
    -- SET XACT_ABORT to ON for ROLLED BACK whene the exception occure
	SET XACT_ABORT ON
	
	BEGIN TRY
		SELECT
			e.ELEMENT_KEY elementKey,
			d.ELEMENT_VALUE elementValue
		FROM
			SITE_DICTIONARY d, SITE_ELEMENTS e
		WHERE e.APP_ID = @app_id
			AND d.SITE_ID = @site_id
			AND d.LANG = @lang_id
			AND e.ISACTIVE='Y'
			AND d.ELEMENT_ID = e.ELEMENT_ID
			
		ORDER BY e.ELEMENT_KEY;
	/*************************************************/
    /*      Capture errors                           */
    /*************************************************/   
		SELECT  @error_var  = @@ERROR, @rowcount_var = @@ROWCOUNT     
	END TRY
    BEGIN CATCH
		PRINT '[USP_GET_SITE_ELEMENTS] CATCH BLOCK EXECUTION';
	    SET @O_SQLCODE = '30';
		SET @O_SQLMSG = '[USP_GET_SITE_ELEMENTS] UNSUCCESSFUL - SQL Error on SELECT: ' + SUBSTRING(CAST(@error_var AS CHAR(06)),1,200);
		RETURN
	END CATCH
   
   PRINT '[USP_GET_SITE_ELEMENTS] END';
	IF @error_var <> 0
	BEGIN
	   SELECT @O_SQLCODE = '30'
	   SELECT @O_SQLMSG  = '[USP_GET_SITE_ELEMENTS] UNSUCCESSFUL - SQL Error on SELECT: ' + ERROR_NUMBER()+' - '+ SUBSTRING(CAST(@error_var AS CHAR(06)),1,200)
	   RETURN
	END
	IF @rowcount_var <= 0
	BEGIN
		SELECT @O_SQLCODE = '1'
	   SELECT @O_SQLMSG  = '[USP_GET_SITE_ELEMENTS] SUCCESSFUL - No records found '
	   RETURN
	END
END 
    
   
GO 

--EXECUTE FAQ.USP_GET_SITE_ELEMENTS '101', @O_SQLCODE='1',@O_SQLMSG=''

