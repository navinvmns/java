USE [PlanDetails]
GO

GO 
IF OBJECT_ID('FAQ.USP_GET_PLAN_DETAILS', 'P') IS NOT NULL  
    DROP PROCEDURE FAQ.USP_GET_PLAN_DETAILS;  
GO
/*******************************************************************************
NAME:       USP_GET_PLAN_DETAILS
PURPOSE:    The main purpose of this procedure IS TO PROVIDE ALL THE
DATA ELEMENTS FOR A PARTICULAR application in terms of plandetails data.

BUILD-LABEL:  #BI#
BUILD-DATE:  #BD#

Procedure Updates Database:
	NO
Procedure Calls Other Procs:
	NO
	
 Input Arguments:
		@client VARCHAR(3)
		@planId VARCHAR(5)
		@divisionCode VARCHAR(3)
		@docId VARCHAR(5)
		@status VARCHAR(1)		
        
 Output Arguments:
		@return_code                   CHAR(03)  
		@return_msg                    CHAR(255)       

Procedure Return Codes (code generated into @O_SQLCODE):
**     0 SUCCESSFUL
**     1 SUCCESSFUL   - No item
**    30 UNSUCCESSFUL - SQL Related      Error on SELECT 
**    31 UNSUCCESSFUL - SQL Input Parameters validation      
**    32 UNSUCCESSFUL - SQL Multiple records found   
**                               
**    2x UNSUCCESSFUL - Data Constraints N/A                                
**    4x UNSUCCESSFUL - External Proc    N/A                               
**    9x UNSUCCESSFUL - Other            N/A  

Procedure Returns Result Set:
	YES

Procedure Returns Result Set:
client, clientId, clientName, planId, planName, planFtr, overrideClientName, showVideo, videoUrl, showFeeDisclosure,
questionNumber, question, answer, isActive	

REVISIONS:
Ver        Date        Author           Description
---------  ----------  ---------------  ---------------------------
1.0        2/06/2018   NAVEEN KUMAR T         Created this procedure.
******************************************************************************/
CREATE PROCEDURE FAQ.USP_GET_PLAN_DETAILS (                              
                              @client VARCHAR(6),
							  @planId VARCHAR(6),
							  @divisionCode VARCHAR(16),
							  @docId VARCHAR(6),
							  @status VARCHAR(32),
							  @O_SQLCODE   VARCHAR(3) OUTPUT,
                              @O_SQLMSG    VARCHAR(255) OUTPUT,
                              @QNA_SQLCODE   VARCHAR(3) OUTPUT,
                              @QNA_SQLMSG    VARCHAR(255) OUTPUT) 
AS
-- SET NOCOUNT ON added to prevent extra result sets from 
-- interfering with SELECT statements. 
SET nocount ON; 
SET ANSI_WARNINGS OFF
SET QUOTED_IDENTIFIER OFF
/********************************************************************/
/*              D e c l a r a t i o n   of  V a r i a b l e s       */
/********************************************************************/
DECLARE       @error_var            INT
         ,    @rowcount_var         INT
           
/********************************************************************/
/*              I n i t i a l i z a t i o n                         */
/********************************************************************/


/********************************************************************/
/*              M a i n                                             */
/********************************************************************/
BEGIN
	PRINT '[USP_GET_PLAN_DETAILS] START';
	--Input Argument "client" validation
	IF (@client IS NULL OR @client = '')
	BEGIN
		PRINT '[USP_GET_PLAN_DETAILS] client parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] Input Arguments - client can not be null or Empty. ';
		RETURN
	END
	--Input Argument "planId" validation
	IF (@planId IS NULL OR @planId = '')
	BEGIN
		PRINT '[USP_GET_PLAN_DETAILS] planId parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] Input Arguments - planId can not be null or Empty. ';
		RETURN
	END
	--Input Argument "divisionCode" validation
	IF (@divisionCode IS NULL OR @divisionCode = '')
	BEGIN
		SET @divisionCode = '';
	END
	--Input Argument "docId" validation
	IF (@docId IS NULL OR @docId = '')
	BEGIN
		PRINT '[USP_GET_PLAN_DETAILS] docId parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] Input Arguments - docId can not be null or Empty. ';
		RETURN
	END
	--Input Argument "status" validation
	IF (@status IS NULL OR @status = '')
	BEGIN
		PRINT '[USP_GET_PLAN_DETAILS] status parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] Input Arguments - status can not be null or Empty. ';
		RETURN
	END
	 -- SET FLAG VALUES AND SQL CODE/MESSAGES
    SET @O_SQLCODE = 0;
    SET @O_SQLMSG = 'SUCCESS';
    
    -- SET XACT_ABORT to ON for ROLLED BACK whene the exception occure
	SET XACT_ABORT ON
	PRINT '[USP_GET_PLAN_DETAILS] START PLAN_DETAILS';
	BEGIN TRY
	if @divisionCode = ''
		BEGIN
			IF (SELECT COUNT(*) FROM FAQ.PLAN_DETAILS WHERE CLIENT=@client AND PLAN_ID=@planId AND DOCUMENT_ID=@docId AND STATUS=@status) > 1
			BEGIN
				PRINT '[USP_GET_PLAN_DETAILS] More than one row availble for give planid';
				SET @O_SQLCODE = '32';
				SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] - Multiple records available for given PlanId :'+@planId;
				RETURN
			END
			
			SELECT
			p.CLIENT client,
			p.PLAN_ID planId,
			p.DIVISION_CODE divisonCode,
			p.DOCUMENT_ID documentId,			
			p.CONTENT_ID contentId,
			p.CONTENT_APPROVAL_TIME contentApprovalTime,
			p.CLIENT_ID clientId,
			p.PLAN_NAME planName,
			p.OVERRIDE_CLIENT_NAME overrideClientName,
			p.CLIENT_NAME clientName,
			p.SHOW_VIDEO showVideo,
			p.VIDEO_URL videoUrl,
			p.VIDEO_IMAGE videoImage,
			p.VIDEO_TITLE videoTitle,
			p.VIDEO_TRANSCRIPT videoTranscript,
			p.SHOW_FEE_DISCLOSURE showFeeDisclosure,			
			p.PLAN_FTR planFtr,
			p.DIGITAL_EREVIEW_NUMBER digitalEReviewNumber,
			p.CREATED_BY createdBy, 
			p.CREATED_ON createdOn, 
			p.MODLAST_BY modLastBy, 
			p.MODLAST_ON modLastOn
		FROM
			FAQ.PLAN_DETAILS P
		WHERE p.CLIENT = @client
			AND p.PLAN_ID = @planId
			AND p.DOCUMENT_ID = @docId
			AND p.STATUS = @status;
		END
	ELSE
		BEGIN
			SELECT
			p.CLIENT client,
			p.PLAN_ID planId,
			p.DIVISION_CODE divisonCode,
			p.DOCUMENT_ID documentId,			
			p.CONTENT_ID contentId,
			p.CONTENT_APPROVAL_TIME contentApprovalTime,
			p.CLIENT_ID clientId,
			p.PLAN_NAME planName,
			p.OVERRIDE_CLIENT_NAME overrideClientName,
			p.CLIENT_NAME clientName,
			p.SHOW_VIDEO showVideo,
			p.VIDEO_URL videoUrl,
			p.VIDEO_IMAGE videoImage,
			p.VIDEO_TITLE videoTitle,
			p.VIDEO_TRANSCRIPT videoTranscript,
			p.SHOW_FEE_DISCLOSURE showFeeDisclosure,			
			p.PLAN_FTR planFtr,
			p.DIGITAL_EREVIEW_NUMBER digitalEReviewNumber,
			p.CREATED_BY createdBy, 
			p.CREATED_ON createdOn, 
			p.MODLAST_BY modLastBy, 
			p.MODLAST_ON modLastOn
		FROM
			FAQ.PLAN_DETAILS P
		WHERE p.CLIENT = @client
			AND p.PLAN_ID = @planId
			AND p.DIVISION_CODE = @divisionCode
			AND p.DOCUMENT_ID = @docId
			AND p.STATUS = @status;
		END
		
	/*************************************************/
    /*      Capture errors                           */
    /*************************************************/   
		SELECT  @error_var  = @@ERROR, @rowcount_var = @@ROWCOUNT  
		 
	END TRY
    BEGIN CATCH
   		PRINT '[USP_GET_PLAN_DETAILS] CATCH BLOCK EXECUTION ';
	    SET @O_SQLCODE = '30';
		SET @O_SQLMSG = '[USP_GET_PLAN_DETAILS] UNSUCCESSFUL - SQL Error on SELECT: ' + SUBSTRING(CAST(@error_var AS CHAR(06)),1,200);
		RETURN
	END CATCH
   
   PRINT '[USP_GET_PLAN_DETAILS] END PLAN_SETAILS';
	IF @error_var <> 0
	BEGIN
	   SELECT @O_SQLCODE = '30'
	   SELECT @O_SQLMSG  = '[USP_GET_PLAN_DETAILS] UNSUCCESSFUL - SQL Error on SELECT: ' + ERROR_NUMBER()+' - '+ SUBSTRING(CAST(@error_var AS CHAR(06)),1,200)
	   RETURN
	END
	-- No Valid records found check
	IF @rowcount_var <= 0
	BEGIN
	   PRINT '[USP_GET_PLAN_DETAILS] SUCCESSFUL - No records found '
	   SELECT @O_SQLCODE = '1'
	   SELECT @O_SQLMSG  = '[USP_GET_PLAN_DETAILS] SUCCESSFUL - No records found '
	   RETURN
	END
	 -- SET FLAG VALUES AND SQL CODE/MESSAGES
    SET @QNA_SQLCODE = 0;
    SET @QNA_SQLMSG = 'SUCCESS';
	 PRINT '[USP_GET_PLAN_DETAILS] START QNA';
	BEGIN TRY
		if @divisionCode = ''
			BEGIN
				SELECT
					q.QUESTION_SORTORDER questionSortOrder,
					q.QUESTION question,
					q.ANSWER answer,
					q.TEMPLATESECTION_SORTORDER templateSectionSortOrder,
					q.CREATED_BY createdBy, 
					q.CREATED_ON createdOn, 
					q.MODLAST_BY modLastBy, 
					q.MODLAST_ON modLastOn
				FROM
					FAQ.QNA q 			
				WHERE q.CLIENT = @client
					AND q.PLAN_ID = @planId
					AND q.DOCUMENT_ID = @docId
					AND q.STATUS = @status
					AND q.ISACTIVE = 'Y'			
				ORDER BY q.TEMPLATESECTION_SORTORDER asc,  QUESTION_SORTORDER asc;
			END
		ELSE
			BEGIN
				SELECT
					q.QUESTION_SORTORDER questionSortOrder,
					q.QUESTION question,
					q.ANSWER answer,
					q.TEMPLATESECTION_SORTORDER templateSectionSortOrder,
					q.CREATED_BY createdBy, 
					q.CREATED_ON createdOn, 
					q.MODLAST_BY modLastBy, 
					q.MODLAST_ON modLastOn
				FROM
					FAQ.QNA q 			
				WHERE q.CLIENT = @client
					AND q.PLAN_ID = @planId
					AND q.DIVISION_CODE = @divisionCode
					AND q.DOCUMENT_ID = @docId
					AND q.STATUS = @status
					AND q.ISACTIVE = 'Y'			
				ORDER BY q.TEMPLATESECTION_SORTORDER asc,  QUESTION_SORTORDER asc;
			END
		
	/*************************************************/
    /*      Capture errors                           */
    /*************************************************/   
		SELECT  @error_var  = @@ERROR, @rowcount_var = @@ROWCOUNT  
		 
	END TRY
    BEGIN CATCH 
   		PRINT '[USP_GET_PLAN_DETAILS] CATCH BLOCK EXECUTION ';
	    SET @QNA_SQLCODE = '30';
		SET @QNA_SQLMSG = '[USP_GET_PLAN_DETAILS] UNSUCCESSFUL - SQL Error on QNA SELECT: ' + SUBSTRING(CAST(@error_var AS CHAR(06)),1,200);
		RETURN
	END CATCH
   
   PRINT '[USP_GET_PLAN_DETAILS] QNA END';
	IF @error_var <> 0
	BEGIN
	   SELECT @QNA_SQLCODE = '30'
	   SELECT @QNA_SQLMSG  = '[USP_GET_PLAN_DETAILS] UNSUCCESSFUL - SQL Error on QNA SELECT: ' + ERROR_NUMBER()+' - '+ SUBSTRING(CAST(@error_var AS CHAR(06)),1,200)
	   RETURN
	END
	-- No Valid records found check
	IF @rowcount_var <= 0
	BEGIN
	   PRINT '[USP_GET_PLAN_DETAILS] SUCCESSFUL - No records found QNA'
	   SELECT @QNA_SQLCODE = '1'
	   SELECT @QNA_SQLMSG  = '[USP_GET_PLAN_DETAILS] SUCCESSFUL - No records found QNA'
	   RETURN
	END
	PRINT '[USP_GET_PLAN_DETAILS] END';
END 

GO    
   
