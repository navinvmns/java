USE [PlanDetails]
GO

/****** Object:  StoredProcedure [FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW]    Script Date: 03/27/2018 12:07:08 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW]') AND type in (N'P', N'PC'))
DROP PROCEDURE [FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW]
GO

USE [PlanDetails]
GO

/****** Object:  StoredProcedure [FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW]    Script Date: 03/27/2018 12:07:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*******************************************************************************
NAME:       USP_INSERT_PLAN_DETAILS_PREVIEW
PURPOSE:    Procedure inserts/updates the plan details and QNA in FAQ Db whenever 
			data in content is upddated

BUILD-LABEL:  #BI#
BUILD-DATE:  #BD#

Procedure Updates Database:
	YES
Procedure Calls Other Procs:
	NO
	
 Input Arguments:
		@client VARCHAR(3)
		@planId VARCHAR(5)
		@divisionCode VARCHAR(3)
		@docId VARCHAR(5)
		@status VARCHAR(1)
		@ClientName VARCHAR(256)
		@username varchar(32)
	    @overrideClientName char(1) 
		@planName varchar(256) 
		@showVideo char(1) 
		@VideoUrl varchar(512) 
		@showFD char(1)
		@planftr varchar(2048)
		@templatesectionid int
		@templatesection_order int 
		@q_number integer
		@question varchar(8000)
		@Answer varchar(8000)
		@isActive CHAR(1)
        
 Output Arguments:
		@O_SQLCODE                  CHAR(03)  
		@O_SQLMSG					CHAR(255)
		@QNA_SQLCODE				CHAR(03)
		@QNA_SQLMSG					CHAR(255)

Procedure Return Codes (code generated into @O_SQLCODE):
**     0 SUCCESSFUL
**     1 SUCCESSFUL   - No item
**    30 UNSUCCESSFUL - SQL Related      Error on SELECT 
**    31 UNSUCCESSFUL - SQL Input Parameters validation      
**                               
**    2x UNSUCCESSFUL - Data Constraints N/A                                
**    4x UNSUCCESSFUL - External Proc    N/A                               
**    9x UNSUCCESSFUL - Other            N/A  

Procedure Returns Result Set:
	YES

Procedure Returns Result Set:
client, clientId, clientName, planId, planName, planFtr, overrideClientName, showVideo, videoUrl, showFeeDisclosure,
questionNumber, question, answer, isActive	

REVISIONS:
Ver        Date        Author           Description
---------  ----------  ---------------  ---------------------------
1.0        2/20/2018   Omkar Sangaraju  Procedure created.
******************************************************************************/
CREATE PROCEDURE [FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW] (
							  @client VARCHAR(3),
							  @planId VARCHAR(5),
							  @divisionCode VARCHAR(3),
							  @docId VARCHAR(5),
							  @contentId INT,
							  @username VARCHAR(32),
							  @overrideClientName CHAR(1) = 'N',
							  @clientName VARCHAR(256),
							  @planName VARCHAR(256) = Null,
							  @showVideo CHAR(1) = Null,
							  @VideoUrl VARCHAR(512) = Null,
							  @VideoImage VARCHAR(512) = Null,
							  @VideoTitle VARCHAR(2048) = Null,
							  @VideoTranscript VARCHAR(512) = NULL,
							  @showFD CHAR(1) = Null,
							  @planftr VARCHAR(8000) = Null,
							  @QNAtable FAQ.QNADATATYPE READONLY,
							  @O_SQLCODE   VARCHAR(3) OUTPUT,
                              @O_SQLMSG    VARCHAR(255) OUTPUT,
                              @QNA_SQLCODE   VARCHAR(3) OUTPUT,
                              @QNA_SQLMSG    VARCHAR(255) OUTPUT )
AS

SET NOCOUNT ON;

/********************************************************************/
/*              D e c l a r a t i o n   of  V a r i a b l e s       */
/********************************************************************/
DECLARE		@planDetailsUpdate		bit = 0
		,	@QNAUpdate				bit = 0
		,	@error_var            INT
        ,   @rowcount_var         INT	
           
/********************************************************************/
/*              I n i t i a l i z a t i o n                         */
/********************************************************************/


/********************************************************************/
/*              M a i n                                             */
/********************************************************************/
BEGIN
    PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] START';
    
    -- begin input validation
    IF (@client IS NULL OR @client = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] client parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - client can not be null or Empty. ';
		RETURN
	END
	
	IF (@planId IS NULL OR @planId = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] planId parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - planId can not be null or Empty. ';
		RETURN
	END
	
	IF (@divisionCode IS NULL OR @divisionCode = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] divisionCode parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - divisionCode can not be null or Empty. ';
		RETURN
	END
	
	IF (@docId IS NULL OR @docId = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] docId parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - docId can not be null or Empty. ';
		RETURN
	END
	
	IF (@contentId IS NULL OR @contentId = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] contentId parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - Contentid can not be null or Empty. ';
		RETURN
	END	
	
	
	IF (@username IS NULL OR @username = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] @username parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - @username can not be null or Empty. ';
		RETURN
	END
	
	IF (@planName IS NULL OR @planName = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] @planName parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - @planName can not be null or Empty. ';
		RETURN
	END
	
	IF (@showVideo IS NULL OR @showVideo = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] @showVideo parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - @showVideo can not be null or Empty. ';
		RETURN
	END
	
	IF @showVideo = 'Y'
	BEGIN
		IF (@VideoUrl IS NULL OR @VideoUrl = '')
		BEGIN
			PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] @VideoUrl parameter can not be null or Empty';
			SET @O_SQLCODE = '31';
			SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - @VideoUrl can not be null or Empty. ';
			RETURN
		END
		
		IF (@VideoImage IS NULL OR @VideoImage = '')
		BEGIN
			PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] @VideoImage parameter can not be null or Empty';
			SET @O_SQLCODE = '31';
			SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - @VideoImage can not be null or Empty. ';
			RETURN
		END
		
		IF (@VideoTitle IS NULL OR @VideoTitle = '')
		BEGIN
			PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] @VideoTitle parameter can not be null or Empty';
			SET @O_SQLCODE = '31';
			SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - @VideoTitle can not be null or Empty. ';
			RETURN
		END	 
		
		IF (@VideoTranscript IS NULL OR @VideoTranscript = '')
		BEGIN
			PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] @@VideoTranscript parameter can not be null or Empty';
			SET @O_SQLCODE = '31';
			SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - @@VideoTranscript can not be null or Empty. ';
			RETURN
		END	 
	END  

	/* IF (@showFD IS NULL OR @showFD = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] Show fee disclosure parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - Show fee disclosure can not be null or Empty. ';
		RETURN
	END */
	
	/* IF (@planftr IS NULL OR @planftr = '')
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] Plan Footer parameter can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - Plan features can not be null or Empty. ';
		RETURN
	END */
	
	
	-- Taking out validation for QNA table since the same procedure can be used for creating plans.
	/* IF NOT EXISTS(SELECT TOP 1 templatesectionid FROM @QNATable)
	BEGIN
		PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] QNA data can not be null or Empty';
		SET @O_SQLCODE = '31';
		SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] Input Arguments - QNA data can not be null or Empty. ';
		RETURN
	END */ 	
	
		
	IF EXISTS(SELECT TOP 1 CONTENT_ID FROM FAQ.PLAN_DETAILS
				WHERE PLAN_ID = @planId
					AND DOCUMENT_ID = @docId
					AND CLIENT = @client
					AND DIVISION_CODE = @divisionCode
					AND CONTENT_ID = @contentId
					AND STATUS = 'PREVIEW')
		BEGIN
			BEGIN TRY
				UPDATE FAQ.PLAN_DETAILS
						SET DIVISION_CODE = @divisionCode
						,	OVERRIDE_CLIENT_NAME = @overrideClientName
						,	CLIENT_NAME = @clientName
						,	PLAN_NAME = @planName
						,	SHOW_VIDEO = @showVideo
						,	VIDEO_URL = @VideoUrl
						,	VIDEO_IMAGE = @VideoImage
						,	VIDEO_TITLE = @VideoTitle
						,	VIDEO_TRANSCRIPT = @VideoTranscript
						,	SHOW_FEE_DISCLOSURE = @showFD
						,	PLAN_FTR = @planftr
						,	MODLAST_BY = @username
						,	MODLAST_ON = GETDATE()
					WHERE
							PLAN_ID = @planId
						AND CONTENT_ID = @contentId
						AND DOCUMENT_ID = @docId
						AND CLIENT = @client
						AND DIVISION_CODE = @divisionCode
						AND STATUS = 'PREVIEW'
					
			END TRY
			BEGIN CATCH				
				SELECT  @error_var  = @@ERROR 			
				PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] CATCH BLOCK EXECUTION ';
				SET @O_SQLCODE = '30';
				SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] UNSUCCESSFUL - SQL Error on PLAN_DETAILS update: ' 
										+ SUBSTRING(CAST(@error_var AS CHAR(06)),1,200) + ' Error: ' + ERROR_MESSAGE();
				RETURN
			END CATCH
		END
	-- Insert the plan details
	ELSE		
		BEGIN			
			BEGIN TRY
				INSERT INTO FAQ.PLAN_DETAILS
					(CLIENT, PLAN_ID, DIVISION_CODE, DOCUMENT_ID, STATUS, CONTENT_ID, CONTENT_APPROVAL_TIME, CLIENT_ID, OVERRIDE_CLIENT_NAME,
						PLAN_NAME, CLIENT_NAME, SHOW_VIDEO, VIDEO_URL, VIDEO_IMAGE, VIDEO_TITLE, VIDEO_TRANSCRIPT, SHOW_FEE_DISCLOSURE, PLAN_FTR, CREATED_ON, CREATED_BY, MODLAST_ON, MODLAST_BY)
				VALUES (@client, @planId, @divisionCode, @docId, 'PREVIEW', @contentId, GETDATE(), @client, @overrideClientName, 
						@planName, @clientName, @showVideo, @VideoUrl, @VideoImage, @VideoTitle, @VideoTranscript, @showFD, @planftr, GETDATE(), @username, GETDATE(), @username)
			END TRY
			BEGIN CATCH
				SELECT  @error_var  = @@ERROR
				PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] CATCH BLOCK EXECUTION ';
				SET @O_SQLCODE = '30';
				SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] UNSUCCESSFUL - SQL Error on PLAN_DETAILS Insert: ' 
									+ SUBSTRING(CAST(@error_var AS CHAR(06)),1,200) +  ' Error: ' + ERROR_MESSAGE();
				RETURN
			END CATCH
		END		
	
	BEGIN TRY
		-- Delete and insert QNA data
		DELETE FROM FAQ.QNA WHERE PLAN_ID = @planId
							AND DOCUMENT_ID = @docId
							AND CLIENT = @client
							AND DIVISION_CODE = @divisionCode
							AND STATUS = 'PREVIEW'
		
		INSERT INTO FAQ.QNA
				(CLIENT, PLAN_ID, DIVISION_CODE, DOCUMENT_ID, STATUS, QUESTION_SORTORDER, QUESTION, ANSWER, TEMPLATE_SECTIONID,
					TEMPLATESECTION_SORTORDER, ISACTIVE, CREATED_ON, CREATED_BY, MODLAST_ON, MODLAST_BY)
			SELECT @client, @planId, @divisionCode, @docId, 'PREVIEW', tqna.Q_number, tqna.Question, tqna.Answer, tqna.TemplateSectionId,
					tqna.TemplateSection_order, CASE WHEN tqna.IsActive = 1 THEN 'Y' ELSE 'N' END, GETDATE(), @username, GETDATE(), @username
				FROM @QNATable tqna
					LEFT JOIN FAQ.QNA fqna ON fqna.TEMPLATE_SECTIONID = tqna.TemplateSectionid 
							AND fqna.QUESTION_SORTORDER = tqna.Q_number 
							AND fqna.PLAN_ID = @planId
							AND fqna.DOCUMENT_ID = @docId
							AND fqna.CLIENT = @client
							AND fqna.DIVISION_CODE = @divisionCode
					WHERE fqna.TEMPLATE_SECTIONID IS NULL
			
	END TRY
	BEGIN CATCH
		SELECT  @error_var  = @@ERROR 			
			PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] CATCH BLOCK EXECUTION ';
			SET @O_SQLCODE = '30';
			SET @O_SQLMSG = '[USP_INSERT_PLAN_DETAILS_PREVIEW] UNSUCCESSFUL - SQL Error on QNA Update/Insert: ' 
								+ SUBSTRING(CAST(@error_var AS CHAR(06)),1,200) + ' Error: ' + ERROR_MESSAGE();
			RETURN		
	END CATCH	
    
    PRINT '[USP_INSERT_PLAN_DETAILS_PREVIEW] END';
END


GO