-- This is the main caller for each script
SET NOCOUNT ON
GO

print '--'+  @@servername
print '--'+  convert(varchar(25),Getdate(),121)
print '--'+  suser_sname()

:On Error exit

USE [#ENV_DB_NAME#]
GO

PRINT 'START'
GO

:setvar path "C:\tmp\DB\#APP_NAME#\#ENV_DB_NAME#"

:r $(path)\DDL\CONFIG_DETAILS.sql
:r $(path)\DDL\PLAN_DETAILS.sql
:r $(path)\DDL\PLAN_DETAILS_HIST.sql
:r $(path)\DDL\QNA.sql
:r $(path)\DDL\QNA_HIST.sql
:r $(path)\DDL\SITE_DETAILS.sql
:r $(path)\DML\INSER_SITE_DETAILS.sql
:r $(path)\DML\INSERT_CONFIG_DETAILS.sql
:r $(path)\DML\INSERT_PLAN_DETAILS.sql
:r $(path)\TYPES\QNADATATYPE.sql
:r $(path)\PROCEDURES\USP_INSERT_PLAN_DETAILS_PREVIEW.sql
:r $(path)\PROCEDURES\USP_GET_CONFIG_OBJECT.sql
:r $(path)\PROCEDURES\USP_GET_PLAN_DETAILS.sql
:r $(path)\PROCEDURES\USP_GET_SITE_ELEMENTS.sql
:r $(path)\TRIGGERS\TRG_PLAN_DETAILS.sql
:r $(path)\TRIGGERS\TRG_QNA.sql
PRINT 'COMPLETE'
GO