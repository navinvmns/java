-- This is the main caller for each script
SET NOCOUNT ON
GO

print '--'+  @@servername
print '--'+  convert(varchar(25),Getdate(),121)
print '--'+  suser_sname()

:On Error exit

USE [#ENV_DB_NAME#]
GO

PRINT 'START'
GO

:setvar path "C:\tmp\DB\#APP_NAME#\#ENV_DB_NAME#"
:r $(path)\DML\Sample.sql
PRINT 'COMPLETE'
GO
