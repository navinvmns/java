/****** Object:  StoredProcedure [FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW]  ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW]') AND type in (N'P', N'PC'))
DROP PROCEDURE [FAQ].[USP_INSERT_PLAN_DETAILS_PREVIEW]
GO

/****** Object:  UserDefinedTableType [FAQ].[QNADATATYPE]    Script Date: 02/22/2018 16:53:10 ******/
IF  EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'QNADATATYPE' AND ss.name = N'FAQ')
DROP TYPE [FAQ].[QNADATATYPE]
GO

/* BUILD-LABEL:  #BI#
** BUILD-DATE:  #BD# 
*/

/****** Object:  UserDefinedTableType [FAQ].[QNADATATYPE]    Script Date: 02/22/2018 16:53:10 ******/
CREATE TYPE [FAQ].[QNADATATYPE] AS TABLE(
	[TemplateSectionid] [int] NOT NULL,
	[TemplateSection_order] [int] NOT NULL,
	[Q_number] [int] NOT NULL,
	[Question] [varchar](8000) NOT NULL,
	[Answer] [varchar](8000) NOT NULL,
	[IsActive] [char](1) NOT NULL
)
GO


